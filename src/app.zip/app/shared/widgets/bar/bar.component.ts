import { AfterViewInit, Component, NgZone, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import {
  ApexAxisChartSeries,
  ApexChart,
  ChartComponent,
  ApexDataLabels,
  ApexPlotOptions,
  ApexYAxis,
  ApexLegend,
  ApexStroke,
  ApexXAxis,
  ApexFill,
  ApexTooltip,
  ApexTitleSubtitle
} from "ng-apexcharts";
export type ChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  dataLabels: ApexDataLabels;
  plotOptions: ApexPlotOptions;
  yaxis: ApexYAxis;
  axis: ApexXAxis;
  fill: ApexFill;
  tooltip: ApexTooltip;
  stroke: ApexStroke;
  legend: ApexLegend;
  title: ApexTitleSubtitle
};

@Component({
  selector: 'app-widget-bar',
  templateUrl: './bar.component.html',
  styleUrls: ['./bar.component.scss']
})
export class BarComponent implements OnInit {

  @ViewChild("chart") chart!: ChartComponent;
  public chartOptions: any;

  constructor(private http: HttpClient) {}
    
  ngOnInit(): void {
    this.chartOptions = {
      series: [
        {
          name: "",
          data: []
        }
      ],
      chart: {
        height: 350,
        type: "line",
        zoom: {
          enabled: false
        }
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        curve: "straight"
      },
      title: {
        text: "OTD & Productivity",
        align: "left"
      },
      grid: {
        row: {
          colors: ["#f3f3f3", "transparent"], // takes an array which will be repeated on columns
          opacity: 0.5
        }
      },
      xaxis: {
        title: {
          text: "Month"
        },
        categories: []
      },
      yaxis: {
        title: {
          text: "OTD/Prod"
        }
      }
    };
    this.getChartData();
  }

  async getChartData() {
    const chartData = await this.http.get<any>('https://run.mocky.io/v3/6c11409f-bc10-4fa1-9bcf-5440e24698a5').toPromise();
    const { data } = chartData;
    console.log(data);
    let Xaxis: any[] = [];
    let Yaxis: any[] = [];
    data.forEach((ele: any, i: any) => {
      Xaxis.push(ele.Month);
      Yaxis.push(Number(ele.RFT));
    });
    this.chartOptions.series = [{
      data: [...Yaxis]
    }]
    this.chartOptions.xaxis.categories.push(...Xaxis);
  }
  filterObject(objectPassed: any, filterArray: any[]) {
    return filterArray.reduce((acc, record) => (record in objectPassed && (acc[record] = objectPassed[record]), acc), {});
  }

}


